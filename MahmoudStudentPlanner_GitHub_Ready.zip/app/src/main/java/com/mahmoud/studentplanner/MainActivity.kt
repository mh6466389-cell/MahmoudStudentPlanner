package com.mahmoud.studentplanner

import android.app.Activity
import android.os.Bundle
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var subject: EditText
    private lateinit var homework: EditText
    private lateinit var date: EditText
    private lateinit var list: TextView
    private val tasks = mutableListOf<Task>()

    data class Task(val subject:String,val homework:String,val date:String,var done:Boolean=false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        subject=findViewById(R.id.subject); homework=findViewById(R.id.homework)
        date=findViewById(R.id.date); list=findViewById(R.id.list)
        load()
        findViewById<Button>(R.id.add).setOnClickListener { addTask() }
        findViewById<Button>(R.id.today).setOnClickListener { render(true) }
        render(false)
    }

    private fun addTask(){
        val s=subject.text.toString().trim(); val h=homework.text.toString().trim(); val d=date.text.toString().trim()
        if(s.isEmpty()||h.isEmpty()||d.isEmpty()){ Toast.makeText(this,"املأ كل البيانات",Toast.LENGTH_SHORT).show(); return }
        tasks.add(Task(s,h,d)); save(); subject.text.clear(); homework.text.clear(); date.text.clear(); render(false)
    }

    private fun render(today:Boolean){
        if(tasks.isEmpty()){ list.text="لا توجد مهام حاليًا."; return }
        val shown=if(today) tasks.filter { it.date==date.text.toString().trim() && !it.done } else tasks
        if(shown.isEmpty()){ list.text="🎯 لا توجد مهام مطابقة."; return }
        list.text=shown.mapIndexed { _,t ->
            val mark=if(t.done)"✅" else "⬜"
            "$mark  ${t.subject} — ${t.homework}\n📅 ${t.date}\n"
        }.joinToString("\n")
    }

    private fun save(){
        val a=JSONArray()
        tasks.forEach{ a.put(JSONObject().put("s",it.subject).put("h",it.homework).put("d",it.date).put("done",it.done)) }
        getPreferences(0).edit().putString("tasks",a.toString()).apply()
    }
    private fun load(){
        val raw=getPreferences(0).getString("tasks","[]") ?: "[]"
        val a=JSONArray(raw)
        for(i in 0 until a.length()){ val o=a.getJSONObject(i); tasks.add(Task(o.getString("s"),o.getString("h"),o.getString("d"),o.optBoolean("done"))) }
    }
}
